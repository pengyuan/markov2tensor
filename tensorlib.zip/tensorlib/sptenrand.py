#!/usr/bin/python


def sptenrand(sz, nz):
    
    #if (nz < 0) error